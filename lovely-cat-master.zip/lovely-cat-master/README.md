A lovely cat which will follow your mouse to move:

![](cat.gif)

## Run
If you want to  run the project on localhost, you can use http server , such as ` http-server `

## Demo
click [lover-cat](https://zhanyuzhang.github.io/lovely-cat/cat.html) and then you will see a lovely black cat on the page!

## How to use it in your blog ?
The cat is so lovely that you maybe want to import it to your blog. You can use `iframe` element, as follows:
```
  <iframe src="https://zhanyuzhang.github.io/lovely-cat/cat.html" border="0"></iframe>
```

Enjoy yourself!


