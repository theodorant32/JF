﻿

namespace Presentation.Common
{
    public enum SelectionState
    {
        Default,
        Watering,
        Deleting
    }
}
