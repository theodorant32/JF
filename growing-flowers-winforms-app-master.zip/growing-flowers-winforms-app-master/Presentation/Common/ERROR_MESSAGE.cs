﻿

namespace Presentation.Common
{
    internal static class ERROR_MESSAGE
    {
        internal const string NAME_IS_EMPTHY = "Name must not be empty";
        internal const string NAME_IS_TOO_LONG = "Name is to long";
        internal static string NAME_IS_ALREADY_EXISTS = "Flower with name {0} is already exists";

        internal const string NO_FREE_POTS = "There aren't any free pots available :(";
    }
}
