﻿

namespace Presentation.Views
{
    public interface IView
    {

    }
}
