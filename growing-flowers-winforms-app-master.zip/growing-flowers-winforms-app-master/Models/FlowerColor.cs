﻿

namespace Models
{
    //localization
    public enum FlowerColor
    {
        Red,
        Yellow,
        Blue,
        Violet
    }
}
